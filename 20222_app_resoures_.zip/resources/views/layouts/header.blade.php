<!DOCTYPE html>
<html>
<head>
    <title>News blog </title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<style>
    .all_posts .card-title
    {
        font-size: 30px;
        font-weight: bold;
        font-style: italic;
    }    .all_posts .card-text
    {
        font-size: 20px;
     }  .all_posts  img:hover
    {
     filter: brightness(0.5);
     }
</style>
</head>
<body>
