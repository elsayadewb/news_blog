@include('layouts.header')

<div class="container">

    @yield('content')
</div>
@include('layouts.footer')
