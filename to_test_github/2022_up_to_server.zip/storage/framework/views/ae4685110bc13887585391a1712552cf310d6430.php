
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            

            <section class="all_posts">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card -bg-gray-50  " >
                                <div class="-card-header">

                                    <?php echo $__env->make('message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keypost => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card-body"  style="padding: 20px" >
                                        <h5 class="card-title"><?php echo e($keypost.':'.  \Str::limit($post->title, 100)); ?></h5>
                                        <p class="card-text"><?php echo e($keypost.':'.  \Str::limit($post->description, 100)); ?></p>
                                        <img src="https://santrikoding.com/storage/posts/TtMZketk0AUZRGmBwqVzUsAbzMdN62f3og2USjEd.png" class="card-img-top" alt="..." style="width: 100%;  height: 500px">
                                        <br/><br/>

                                        <div class="col-xs-12 col-sm-12 col-md-12" >
                                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($comment->post_id ==  $post->id): ?>
                                                    <div style="border:5px dashed #777;padding: 10px">
                                                        <p><i class="fas fa-comment-dots"></i> <?php echo e($key.':'.  \Str::limit($comment->description, 100)); ?></p>
                                                    </div><br/>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(url('store/comment')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="row ">
                                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                                        <div class="form-group">
                                                            <strong>add nwe comment  :</strong>
                                                            <textarea  class="form-control" style="height:100px;border:1px dashed  #888 " name="description" placeholder="Enter Description"></textarea>
                                                            <?php if(auth()->guard()->check()): ?>
                                                                <input  class="form-control"   type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                                <input  class="form-control"     type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                                            <?php endif; ?>
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                                        <button type="submit" class="btn btn-primary">Add comment <i class="far fa-comments"></i></button>
                                                    </div>
                                                </div>

                                            </form>
                                        <?php else: ?>
                                            if you want to add comment please login <a href="/login">login</a>
                                        <?php endif; ?>
                                    </div>



                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- col-md-12-->
                    </div><!-- row-->
                </div><!-- container-->
            </section><!--all_posts-->
        </div>
    </div>
</div>

<?php /**PATH F:\xampp\htdocs\mo4\2022\resources\views/dashboard.blade.php ENDPATH**/ ?>