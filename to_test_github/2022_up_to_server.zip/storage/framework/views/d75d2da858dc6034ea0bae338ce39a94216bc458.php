
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>" class="btn btn-dark"> <i class="fas fa-arrow-left"></i> Back</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('posts')); ?>" class="btn btn-dark"> <i class="far fa-newspaper"></i>  posts</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('users')); ?>" class="btn btn-dark"> <i class="fa  fa-users"></i>  users</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('comments')); ?>" class="btn btn-dark"> <i class="fa  fa-comments"></i>  comments</a></li>
        <?php if( url()->current() == url('/dashboard') ||  url()->current() ==  url('/') ||  url()->current() ==  url('/home') ): ?>

        <?php else: ?>
            <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url()->current().'/create'); ?>" class="btn btn-dark"> <i class="fa  fa-plus"></i>  create new  record </a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(url('')); ?>" class="btn btn-dark"> <i class="fas fa-home-alt"></i>  Home</a></li>

        <?php endif; ?>


    </ol>
</nav>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH F:\xampp\htdocs\mo4\2022\resources\views/message.blade.php ENDPATH**/ ?>